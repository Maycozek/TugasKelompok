﻿Public Class Form1
    Private Sub HellowordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HellowordToolStripMenuItem.Click

    End Sub
End Class
